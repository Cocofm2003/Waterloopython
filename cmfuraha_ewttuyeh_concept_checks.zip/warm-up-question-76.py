def a_phobic(s: str) -> str:
  '''
  Returns s without 'a's and if the number of 'a's removed was even,
  we also append a '!' character.
  
  Examples:
     a_phobic("") => "!"
     a_phobic("bananab") => "bnnb"
  '''
  ##YOUR CODE GOES HERE
  pass

def a_phobic(s: str) -> str:
    result = ""
    removed = 0
    for ch in s:
        if ch == 'a':
            removed += 1
        else:
            result += ch
    if removed % 2 == 0:
        result += "!"
    return result
