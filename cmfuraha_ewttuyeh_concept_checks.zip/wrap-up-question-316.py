def analyze_string(s: str) -> None:
  """
  Prints to the screen:
  contains C characters, P spaces, and ends with 'E'.
  (including the period above) where:
  C is the length of s, 
  P is the number of spaces (' ') in s
  E is the last character in s.
  
  Effects:
     Prints to screen
  
  Examples:
     analyze_string("") => None
     and prints
     contains 0 characters, 0 spaces, and ends with ''.
  
     analyze_string("Bananas are ripe!") => None
     and prints
     contains 17 characters, 2 spaces, and ends with '!'.
  """
  ##YOUR CODE GOES HERE
  pass

def analyze_string(s: str) -> None:
    # Count characters and spaces
    C = len(s)
    P = s.count(" ")
    
    # Determine last character (or empty string if s is empty)
    E = s[-1] if s else ""
    
    # Print the required message
    print(f"contains {C} characters, {P} spaces, and ends with '{E}'.")
