def make_list(n: int) -> list[str]:
  '''
  Returns the list of strings formed by in position n, 
  repeating n a total of n times
  
  Requires: n >= 0
  
  Examples:
     make_list(0) => ['']
     make_list(3) => ['', '1', '22', '333']
  '''
  ##YOUR CODE GOES HERE
  pass

def make_list(n: int) -> list[str]:
    result = []
    for i in range(n + 1):
        if i == 0:
            result.append("")
        else:
            result.append(str(i) * i)
    return result
