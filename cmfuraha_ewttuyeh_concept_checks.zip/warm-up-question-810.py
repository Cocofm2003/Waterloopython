def total(t: tuple[int], fnameout: str) -> None:
  """
  Writes the sum of t in fnameout.
  
  Effects:
     Writes to a file
  
  Examples:
     total((),"empty.txt") => None
     and empty.txt contains:
     0
     
     total((1,2,3),"ex1.txt") => None
     and ex1.txt contains:
     6

  """
  ##YOUR CODE GOES HERE
  pass

def total(t: tuple[int], fnameout: str) -> None:
    with open(fnameout, 'w') as f:
        f.write(str(sum(t)) + '\n')
