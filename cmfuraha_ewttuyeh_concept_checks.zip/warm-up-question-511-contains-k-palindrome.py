def contains_consecutive_k_palindrome(s: str, k: int) -> bool:
  """
  Returns whether or not s contains string of
  k consecutive letters that form a palindrome
  
  Requires: k > 0
  
  Examples:
     contains_consecutive_k_palindrome("", 1) => False
     contains_consecutive_k_palindrome("a", 1) => True
     contains_consecutive_k_palindrome("asdf", 2) => False
     contains_consecutive_k_palindrome("banana", 3) => True
  """
  ##YOUR CODE GOES HERE
  pass

def contains_consecutive_k_palindrome(s: str, k: int) -> bool:
    if k > len(s) or k <= 0:
        return False
    for i in range(len(s) - k + 1):
        substring = s[i:i+k]
        if substring == substring[::-1]:
            return True
    return False
