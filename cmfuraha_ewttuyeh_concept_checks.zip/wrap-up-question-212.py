def sum_powers(b: int, n: int) -> int:
  """
  Returns 1 + b + ... + b^n
  
  Requires: n >= 0
  
  Examples:
     sum_powers(0, 0) => 1
     sum_powers(0, 100) => 1
     sum_powers(2, 3) => 15
  """
  
  total = 0
  power = 0

  while power <= n:
      total += b ** power
      power += 1

  return total
