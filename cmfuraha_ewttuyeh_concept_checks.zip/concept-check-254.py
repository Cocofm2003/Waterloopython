def factorial(n: int) -> int:
  """
  Returns n!
  
  Requires: n >= 0
  
  Examples:
     factorial(0) => 1
     factorial(4) => 24
  """
  ##YOUR CODE GOES HERE
  
def factorial(n):
    total = 1
    while n > 0:
        total *= n
        n -= 1
    return total
