def reversed_multiple_tuple(t: tuple, start: int, k: int) -> tuple:
  """
  Returns a reverse of every kth element in t 
  starting with start (zero indexed)
  
  Requires: 
     0 <= start
     0 < k
  
  Examples:
     reversed_multiple_tuple((), 0, 1) => ()
     reversed_multiple_tuple((1,2,3,4,5,6,7,8,9), 2, 5) => (8, 3)
  """
  ##YOUR CODE GOES HERE
  pass
  
def reversed_multiple_tuple(t: tuple, start: int, k: int) -> tuple:
    # Base case: if start is out of range, return empty tuple
    if start >= len(t):
        return ()
    
    # Recursive case: take the element at 'start', then move k steps forward
    return reversed_multiple_tuple(t, start + k, k) + (t[start],)

