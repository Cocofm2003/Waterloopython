#the check module is automatically imported for this question
check.expect("Example 1", in_interval(1,5,3), 1)
check.expect("Example 2", in_interval(1,5,7), 0)
check.expect("Test 1", in_interval(2,9,2), 1)
check.expect("Test 2", in_interval(2,9,9), 1)
check.expect("Test 3", in_interval(0,8,4), 1)
check.expect("Test 4", in_interval(0,7,0), 1)
check.expect("Test 5", in_interval(10**6,10**8,10**7), 1)
check.expect("Test 6", in_interval(10**6,10**8,10**10), 0)