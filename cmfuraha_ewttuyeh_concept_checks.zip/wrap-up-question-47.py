def find_all_subs(s: str, sub: str) -> tuple[int, ...]:
  """
  Returns a list of positions in s where sub can be found.

  Requires:
     sub != ''
  
  Examples:
     find_all_subs("", "a") => ()
     find_all_subs("aaa", "a") => (0, 1, 2)
     find_all_subs("banana", "an") => (1, 3)
  """
  ##YOUR CODE GOES HERE
  pass

def find_all_subs(s: str, sub: str) -> tuple[int, ...]:
    """
    Returns a tuple of positions in s where sub can be found.
    Requires:
        sub != ''
    """
    positions = []
    pos = 0
    while pos <= len(s) - len(sub):
      if s[pos:pos + len(sub)] == sub:
         positions.append(pos)
         pos += 1
