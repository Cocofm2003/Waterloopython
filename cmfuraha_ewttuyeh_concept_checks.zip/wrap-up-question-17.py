def n_sphere_volume(n: int, r: float) -> float:
  """
  Returns the volume of the n-sphere of radius r
  
  Requires: 
     2 <= n
     0.0 <= r
  
  Examples:
     n_sphere_volume(2, 1.0) => 3.141592653589793
     n_sphere_volume(3, 1.0) => 4.1887902047863905
  """
  ##YOUR CODE GOES HERE
  pass

import math

def n_sphere_volume(n: int, r: float) -> float:
    return (math.pi ** (n / 2)) * (r ** n) / math.gamma((n / 2) + 1)
