def cosine_law(a: float, b: float, theta: float) -> float:
  """
  Returns the third side length using 
  the cosine law with side lengths a and b 
  and contained angle theta in radians
  
  cosine_law: Float Float Float -> Float
  Requires:
     0.0 < a
     0.0 < b
     0.0 < theta < math.pi
     
  Example:
     cosine_law(3, 4, math.pi/3) => 3.60555127546
  """
  ##YOUR CODE GOES HERE
  pass