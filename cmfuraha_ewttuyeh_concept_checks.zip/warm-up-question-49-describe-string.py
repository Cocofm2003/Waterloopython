def describe_string(s: str, c: str) -> int:
  """
  Returns the number of characters in s
  minus the non-negative index of the
  rightmost occurrence of c
  plus the number of c occurrences in the string.
  
  Requires: len(c) == 1
  
  Examples:
     describe_string("", 'c') => 1
     describe_string("banana", 'c') => 7
     describe_string("banana", 'a') => 4
  """
  ##YOUR CODE GOES HERE
  pass

def describe_string(s: str, c: str) -> int:
    # Number of characters in s
    length = len(s)
    
    # Rightmost index of c in s (or -1 if not found)
    rightmost_index = s.rfind(c)  # returns -1 if c not found
    
    # Number of occurrences of c in s
    occurrences = s.count(c)
    
    # Compute the result
    return length - rightmost_index + occurrences
