def my_equals(S: set, T: set):
  """
  Returns True if S and T are equal and False otherwise
  
  Examples:
     my_equals(set(), set()) => True
     my_equals(set(), {1}) => False
     my_equals({1}, set()) => False
  """
  ###YOUR CODE GOES HERE
  pass

def my_equals(S: set, T: set) -> bool:
    return S.issubset(T) and T.issubset(S)
