from typing import Any, TypeVar
X = TypeVar('X') 


def key(d: dict[X, Any], v: Any) -> X|None:
  '''
  Returns the key k corresponding to d[k] == v
  or None if no such key exists
  
  Requires: 
     At most one key k satisfying d[k] == v
  
  Examples:
     key({0: 'zero', 1: 'one'}, 'one') => 1
     key({0: 'zero', 1: 'one'}, 'two') => None
  '''
  ##YOUR CODE GOES HERE
  pass

from typing import Any, TypeVar

X = TypeVar('X')

def key(d: dict[X, Any], v: Any) -> X | None:
    for k, val in d.items():
        if val == v:
            return k
    return None
