def largest_even_number(a: int, b: int, c: int) -> int:
  """
  Returns the largest even number of a, b or c
  or the smallest number if all are odd
  
  Examples:
     largest_even_number(2, 100, 4) => 100
     largest_even_number(2, 101, 41) => 2
     largest_even_number(-51, 101, 41) => -51
  """
  ##YOUR CODE GOES HERE
  
def largest_even_number(a: int, b: int, c: int) -> int:
    """
    Returns the largest even number of a, b or c
    or the smallest number if all are odd

    Examples:
        largest_even_number(2, 100, 4) => 100
        largest_even_number(2, 101, 41) => 2
        largest_even_number(-51, 101, 41) => -51
    """
    numbers = [a, b, c]
    even_numbers = [num for num in numbers if num % 2 == 0]

    if even_numbers:
        return max(even_numbers)
    else:
        return min(numbers)
