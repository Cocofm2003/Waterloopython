def equidigital(m: int, n: int) -> bool:
  '''
  Returns True if m and n contain the same digits and False otherwise.
  
  Requires: m, n > 0
  
  Examples:
     equidigital(0, 0) => True
     equidigital(111111112222111, 21) => True
     equidigital(123, 432) => False
  '''
  pass

def equidigital(m: int, n: int) -> bool:
    return set(str(m)) == set(str(n))
