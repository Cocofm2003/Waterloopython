def longest_string(t: tuple[str, ...]) -> str:
  """
  Returns the longest string
  
  Requires:
     len(t) > 0
  
  Examples:
     longest_string(("",)) => ""
     longest_string(("banana", "apple")) => "banana"
     longest_string(("banana", "apples")) => "banana"
  """
  ##YOUR CODE GOES HERE
  pass

def longest_string(t: tuple[str, ...]) -> str:
    longest = t[0]
    for s in t:
        if len(s) > len(longest):
            longest = s
    return longest
