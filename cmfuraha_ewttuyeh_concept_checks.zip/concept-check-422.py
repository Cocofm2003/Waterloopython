def remove_all_vowels() -> str:
  """
  Reads input from the keyboard and takes this string and returns
  this string with all upper or lower case vowels removed.
  
  Effects:
     Reads input from keyboard.
  
  Examples:
    remove_all_vowels() => ""
    if the empty string is given by user input
    
    remove_all_vowels() => "bnn"
    if the string "banana" is given by user input
  """
  ##YOUR CODE GOES HERE
  pass

def remove_all_vowels() -> str:
    s = input("Enter a string: ")
    vowels = "aeiouAEIOU"
    result = ""
    
    for ch in s:
    if ch not in vowels:
    result += ch
    return result
