#use but do not import the check module

check.expect("swap middle letters", swap_two("hello", 1, 3), "hlleo")
check.expect("swap first and last", swap_two("world", 0, 4), "dorlw")
check.expect("swap two-letter string", swap_two("ab", 0, 1), "ba")
check.expect("swap same position", swap_two("ab", 0, 0), "ab")
check.expect("long string swap", swap_two("abcdefghijklmnopqrstuvwxyz", 0, 25), 
"zbcdefghijklmnopqrstuvwxya")
check.expect("swap first two", swap_two("python", 0, 1), "phtyon")
check.expect("swap last two", swap_two("python", 4, 5), "pythno")
check.expect("swap first two", swap_two("python", 0, 1), "phtyon")
check.expect("swap last two", swap_two("python", 4, 5), "pythno")
check.expect("swap same index", swap_two("edge", 2, 2), "edge")
