def reverse(n: int) -> int:
  """
  Returns the two-digit natural number n in reverse order
  
  Requires: 10 <= n <= 99
  
  Examples:
     reverse(10) => 1
     reverse(34) => 43
     reverse(99) => 99
  """
  tens = n // 10
  ones = n % 10
  return ones * 10 + tens 