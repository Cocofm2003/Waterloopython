def repeat() -> None:
  """
  Requests a string and an integer from keyboard
  and repeats the string the integer number of times
  and prints to the screen
  
  Effects:
     Prints to the screen
     Reads input from keyboard
  
  Examples:
     repeat() => None
     
     and abcabcabc is printed assuming the input given is
     abc
     3
     in that order.
  """
  ##YOUR CODE GOES HERE
  pass

def repeat() -> None:
    # Request a string from the user
    text = input("Enter a word: ")
    
    # Request a positive integer from the user
    while True:
        try:
            count = int(input("Enter a positive integer: "))
            if count > 0:
                break
            else:
                print("Please enter a positive integer.")
        except ValueError:
            print("Invalid input. Please enter an integer.")
    
    # Print the string repeated 'count' times
    print(text * count)
