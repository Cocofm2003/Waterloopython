def pig_latin(s: str) -> str:
  """
  Given a lower case Latin alphabet string s, return the 
  Pig Latin equivalent of the word.
  
  Requires:
     s contains only letters from the lower case Latin alphabet.
     s is nonempty.
  
  Examples:
     pig_latin('apple') => 'appleway'
     pig_latin('your') => 'ouryay'
     pig_latin('sun') => 'unsay'
  """
  ##YOUR CODE GOES HERE
  pass
def pig_latin(s):
    """
    Converts a single English word into its Pig Latin equivalent.

    Args:
        s: A non-empty string of lowercase Latin alphabet letters.

    Returns:
        The Pig Latin version of the word.
    """
    
    # Define the vowels (as specified by the rules, 'y' is not a vowel here)
    vowels = 'aeiou'
    
    # Rule 2: If the word begins with a vowel
    if s[0] in vowels:
        return s + 'way'
    else:
        # Rule 1: If the word begins with a consonant (including 'y')
        # s[1:] gets all characters *except* the first one
        # s[0] is the first character
        return s[1:] + s[0] + 'ay'