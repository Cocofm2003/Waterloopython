def print_every_kth_char(k: int) -> None:
  '''
  Prints every kth character to the screen
  
  Effects:
     Prints to screen
  
  Requires: k > 0
  
  Examples:
     print_every_kth_char(1) => None
     and every character from a to z is printed on its own line
     
     print_every_kth_char(10) => None
     and the following is printed:
     a
     k
     u
  '''
  ##YOUR CODE GOES HERE
  pass

def print_every_kth_char(k: int) -> None:
    alphabet = "abcdefghijklmnopqrstuvwxyz"
    for i in range(0, len(alphabet), k):
        print(alphabet[i])
