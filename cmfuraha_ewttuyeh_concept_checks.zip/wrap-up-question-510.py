def halve_evens(L: list[int]) -> None:
  """
  Returns None and mutates L so that all even numbers are halved
  
  Effects: Mutates L
  
  Examples:
     L = []
     halve_evens(L) => None
     and L is still []
     
     L = [1,3,5,7]
     halve_evens(L) => None
     and L is still [1,3,5,7]
     
     L = [1,2,3,4]
     halve_evens(L) => None
     and L has been mutated to [1,1,3,2]
  """
  ##YOUR CODE GOES HERE
  pass

def halve_evens(L: list[int]) -> None:
    """
    Mutates L so that all even numbers are halved.
    """
    for i in range(len(L)):
        if L[i] % 2 == 0:  # Check if even
            L[i] //= 2     # Halve the number
