def vowel_sort(los: list[str]) -> None:
  """
  Mutates the list los so that the elements are sorted in 
  increasing order of the number of vowels (either upper
  or lower case) in the string.
  
  Effects: Mutates los
  
  Examples:
     If L = [] then
     vowel_sort(L) => None
     and L is unchanged
  
     If L = ['aaa', 'adt', 'ab', 'aziubapiqulwerknii', 'eeeeee'] then
     vowel_sort(L) => None
     and L is mutated to ['adt', 'ab', 'aaa', 'eeeeee', 'aziubapiqulwerknii']
     
     If L = ['dog', 'cat', 'fish', 'yyz', 'tuna', 'elephant'] then
     vowel_sort(L) => None
     and L is mutated to ['yyz', 'dog', 'cat', 'fish', 'tuna', 'elephant']
  """
  ##YOUR CODE GOES HERE
  pass
 
def vowel_sort(los: list[str]) -> None:
    vowels = set("aeiouAEIOU")
    
    def count_vowels(s: str) -> int:
        return sum(1 for ch in s if ch in vowels)
    
    los.sort(key=count_vowels)
    