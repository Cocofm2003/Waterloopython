def n_times_no_loops():
  """
  Reads n from keyboard and prints n a total of n times
  once per line
  
  Effects: 
     Reads input from keyboard
     Prints to screen
  
  n_times_no_loops: None -> None
  
  Examples:
     If 0 is entered after 
     n_times_no_loops() => None
     is called, then nothing is printed.
  
     If 2 is entered after 
     n_times_no_loops() => None
     is called, then the following is printed:
     2
     2
     
  """
  ##YOUR CODE GOES HERE
  pass

def n_times_no_loops():
    n = int(input("Enter a natural number: "))
    print((str(n) + '\n') * n, end='')
    return None
