def tuple_score(t: tuple) -> int:
  '''
  Returns the score of t where strings count as 1 point,
  integers count as their value and other types are worth 0.
  
  Examples:
     tuple_score(()) => 0
     tuple_score(("1", 1, True, (1,2,3))) => 2
     tuple_score(("bigword!!!", 99)) => 100
  '''
  ##YOUR CODE GOES HERE
  pass

 score = 0
    for item in t:
        if isinstance(item, str):
            score += 1
        elif isinstance(item, int):
            score += item
        # other types add 0, so no action needed
    return score
