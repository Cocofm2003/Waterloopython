def sum_odd_squares(L: list[int]) -> int:
  """
  Returns the sum of squares of all odd elements in L
  
  Examples:
     sum_odd_squares([]) => 0
     sum_odd_squares([1, 2, 3]) => 10
     sum_odd_squares([2, 4, 6, 8]) => 0
  """
  ##YOUR CODE GOES HERE
  pass

def sum_odd_squares(L: list[int]) -> int:
    """
    Returns the sum of squares of all odd elements in L.
    """
    total = 0
    for x in L:
        if x % 2 != 0:  # Check if odd
            total += x * x
    return total
