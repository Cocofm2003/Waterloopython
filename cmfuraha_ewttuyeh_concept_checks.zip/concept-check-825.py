class Student:
  idt: int
  major: str
  year: int
  
  def __init__(self, new_id: int) -> None:
    """
    Requires: new_id >= 0
    """
    ##YOUR CODE GOES HERE
    pass

class Student:
    idt: int
    major: str
    year: int

    def __init__(self, new_id: int) -> None:
        """
        Initializes a Student object.
        Requires: new_id >= 0
        """
        self.idt = new_id
        self.year = 1
        self.major = "undeclared"

    def __repr__(self) -> str:
        """
        Returns a string representation of the Student object in the form:
        Student(id=..., year=..., major=...)
        """
        return f"Student(id={self.idt}, year={self.year}, major={self.major})"

