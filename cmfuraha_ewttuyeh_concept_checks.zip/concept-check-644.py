def sum_average(L: list[list[int]]) -> None:
  """
  Mutates the list L so that it is sorted in increasing order of sum 
  with ties broken by the decreasing average of the numbers in the list.
  
  Effects: Mutates L
  
  Requires: L[i] != [] for each 0 <= i < len(L)
  
  Examples:
     If L = [] then
     sum_average(L) => None
     and L is unchanged
     
     If L = [[1,0,0,0,0], [1,0,0,0]] then
     sum_average(L) => None
     and L is mutated to [[1,0,0,0], [1,0,0,0,0]]
     
     If L = [[3, 1, 8], [12]] then
     sum_average(L) => None
     and L is mutated to [[12], [3, 1, 8]]
     
     If L = [[3, 1, 8], [100, 1000, 10000] , [2, 3, 4]] then
     sum_average(L) => None
     and L is mutated to [[2, 3, 4], [3, 1, 8], [100, 1000, 10000]]
  """
  ##YOUR CODE GOES HERE
  pass

def sum_average(L: list[list[int]]) -> None:
    L.sort(key=lambda sub: (sum(sub), -(sum(sub)/len(sub))))
