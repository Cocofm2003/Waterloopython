from typing import Any

class Movie:
  name: str
  year: int
  rating: int

  def __init__(self, n: str, y: int, r: int) -> None:
    """
    Constructor: Create a Movie object by 
    calling Movie(n, y, r)
      
    Effects: Mutates Self
    Requires:
      y > 0
      0 <= r <= 10
    """
    self.name = n
    self.year = y
    self.rating = r
    
  def __eq__(self, other: Any) -> bool:
    """
    Returns True if the movies are equal
    and False otherwise
    """
    ##YOUR CODE GOES HERE
    pass

from typing import Any

class Movie:
    name: str
    year: int
    rating: int

    def __init__(self, n: str, y: int, r: int) -> None:
        """
        Constructor: Create a Movie object by calling Movie(n, y, r)
        Requires: y > 0 and 0 <= r <= 10
        """
        self.name = n
        self.year = y
        self.rating = r

    def __eq__(self, other: Any) -> bool:
        """
        Returns True if the movies are equal and False otherwise.
        Two movies are equal if:
        - other is a Movie instance
        - name, year, and rating are the same
        """
        if not isinstance(other, Movie):
            return False
        return (self.name == other.name and
                self.year == other.year and
                self.rating == other.rating)

