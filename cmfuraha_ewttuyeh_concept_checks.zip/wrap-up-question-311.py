def end_height(s: str) -> int:
  """
  Returns the last height starting from zero and going up for each 'u'
  character in s and down for every 'd' character in s.
  
  Requires:
     s consists of only 'u' and 'd' characters.
  
  Examples:
     end_height("") => 0
     end_height("uuuduu") => 4
     end_height("ddddud") => -4
     end_height("uuddu") => 1
  """
  ##YOUR CODE GOES HERE
  pass
def end_height(s: str) -> int:
    height = 0
    for ch in s:
        if ch == 'u':
            height += 1
        elif ch == 'd':
            height -= 1
    return height