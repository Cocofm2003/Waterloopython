def swap_two(s: str, pos1: int, pos2: int) -> str:
  """
  Returns s with s[pos1] and s[pos2] swapped.
  
  Requires:
     len(s) >= 2
     0 <= pos1 <= len(s) - 1
     0 <= pos2 <= len(s) - 1
  
  Examples:
     swap_two("ab", 0, 1) => "ba"
     swap_two("banana", 2, 5) => "baaann"
  """
  ##YOUR CODE GOES HERE
  pass
def swap_two(s: str, pos1: int, pos2: int) -> str:
    # Convert the string into a list (since strings are immutable)
    chars = list(s)
    
    # Swap the characters at pos1 and pos2
    chars[pos1], chars[pos2] = chars[pos2], chars[pos1]
    
    # Convert back to string
    return ''.join(chars)