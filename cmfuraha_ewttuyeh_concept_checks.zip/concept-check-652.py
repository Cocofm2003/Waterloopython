def transpose(L: list[list[int]]) -> list[list[int]]:
  '''
  Returns the transpose of L
  
  Requires: len(L[i]) are equal for all 0 <= i < len(L)
  
  Examples:
     transpose([]) => []
     transpose([[1]]) => [[1]]
     transpose([[1, 2], [3, 4]]) => [[1, 3], [2, 4]]
  '''
  ##YOUR CODE GOES HERE
  pass

def transpose(L: list[list[int]]) -> list[list[int]]:
    return [[L[row][col] for row in range(len(L))] for col in range(len(L[0]))] if L else []
