def record_digits(s: str) -> tuple[int, int, int, int, int,
                                   int, int, int, int, int]:
  '''
  Returns a list of 10 numbers corresponding to the 
  number of occurrences of each digit in the string s
  
  Examples:
     record_digits("") => (0, 0, 0, 0, 0, 
                           0, 0, 0, 0, 0)
     record_digits("banana") => (0, 0, 0, 0, 0, 
                                 0, 0, 0, 0, 0)
     record_digits("34298465fsdf3") => (0, 0, 1, 2, 2, 
                                        1, 1, 0, 1, 1)
  '''
  ##YOUR CODE GOES HERE
  pass

def record_digits(s: str) -> tuple[int, int, int, int, int, int, int, int, int, int]:
    return tuple(sum(1 for ch in s if ch == str(d)) for d in range(10))
