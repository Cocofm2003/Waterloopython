def normal_distribution(x: float, mean: float, std_dev: float):
  """
  Returns corresponding value of the probability density
  function associated with the normal distribution with mean 
  mean, standard deviation std_dev at the value x.
  
  Requires:
     0 < x, mean, std_dev
     
  Examples:
     normal_distribution(3.0, 5.0, 2.0) => 0.12098536225957168
  """
  
  import math
  coefficient = 1 / (std_dev * math.sqrt(2 * math.pi))
  exponent = -((x - mean) ** 2) / (2 * std_dev ** 2)
  return coefficient * math.exp(exponent)
