from typing import Self

class Movie:
  name: str
  year: int
  rating: int

  def __init__(self, n: str, y: int, r: int) -> None:
    """
    Constructor: Create a Movie object by 
    calling Movie(n, y, r)
      
    Effects: Mutates Self
    Requires:
      y > 0
      0 <= r <= 10
    """
    self.name = n
    self.year = y
    self.rating = r
    
  def is_oldest_movie(self, lom: list[Self]) -> bool:
    """
    Returns True if self is older than all movies in lom
    and False otherwise
  
    Examples:
       m = Movie("Shrek", 2001, 8)
       m2 = Movie("Shrek 2", 2004, 7)
       m3 = Movie("Shrek the Third", 2007, 6)
       m.is_oldest_movie([m2, m3]) => True
       m3.is_oldest_movie([]) => True
       m3.is_oldest_movie([m2]) => False
    """
    ##YOUR CODE GOES HERE
    pass
  
class Movie:
    name: str
    year: int
    rating: int

    def __init__(self, n: str, y: int, r: int) -> None:
        self.name = n
        self.year = y
        self.rating = r

    def is_oldest_movie(self, lom: list['Movie']) -> bool:
        for movie in lom:
            if self.year >= movie.year:  # If self is not strictly older
                return False
        return True
