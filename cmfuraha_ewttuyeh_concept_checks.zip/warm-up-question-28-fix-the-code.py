def minimum(a, b):
  return min(a, b)