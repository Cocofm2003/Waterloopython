class Movie:
  name: str
  year: int
  rating: int

  def __init__(self, n: str, y: int, r: int) -> None:
    """
    Constructor: Create a Movie object by 
    calling Movie(n, y, r)
      
    Effects: Mutates Self
    Requires:
      y > 0
      0 <= r <= 10
    """
    self.name = n
    self.year = y
    self.rating = r
    
def movie_sort(lom: list[Movie]) -> None:
  '''
  Returns None and mutates lom to sorted order
  by name field excepting "The" words.
  
  Effects: Mutates lom
  
  Example:
     m = Movie("Shrek", 2001, 8)
     n = Movie("The Lord of the Rings: The Fellowship of the Ring",
              2001, 9)
     L = [m, n]
     movie_sort(L) => None
     and L is mutated to [n, m]
  '''
  ##YOUR CODE GOES HERE
  pass

def movie_sort(lom: list[Movie]) -> None:
    def sort_key(movie: Movie) -> str:
        # If the name starts with "The ", ignore it for sorting
        if movie.name.startswith("The "):
            return movie.name[4:]  # Skip "The "
        return movie.name

    lom.sort(key=sort_key)
