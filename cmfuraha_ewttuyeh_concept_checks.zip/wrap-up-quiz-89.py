from typing import Any

class Name:
  first: str
  last: str
  
  def __init__(self, fn: str, ln: str) -> None:
    """
    Initializes a Name object
    by calling Name(fn ln).
    
    Effects: Mutates self
    """
    self.first = fn
    self.last = ln
        
  def __eq__(self, other: Any) -> bool:
    """
    Returns True if self and other are 
        considered equal, and False otherwise
    """
    return isinstance(other, Name) and \
      self.first == other.first and \
      self.last == other.last
    
        
  def __repr__(self) -> str:
    """
    Returns a representation of the form:
    "self.last, self.first"
      
    Example:
       n = Name("Carmen", "Bruni")
       str(n) => "Bruni, Carmen"
    """
    ##YOUR CODE GOES HERE
    pass

from typing import Any

class Name:
    first: str
    last: str

    def __init__(self, fn: str, ln: str) -> None:
        """
        Initializes a Name object by calling Name(fn, ln).
        """
        self.first = fn
        self.last = ln

    def __eq__(self, other: Any) -> bool:
        """
        Returns True if self and other are considered equal and False otherwise.
        """
        return isinstance(other, Name) and \
               self.first == other.first and \
               self.last == other.last

    def __repr__(self) -> str:
        """
        Returns a representation of the form:
        last_name, first_name
        """
        return f"{self.last}, {self.first}"

    def __str__(self) -> str:
        """
        Returns a user-friendly string representation of the Name object.
        """
        return f"{self.last}, {self.first}"

