def my_max(L: list[int|float]|list[str]) -> int|float|str:
  """
  Returns the maximum of L.

  Requires: L is non-empty
  
  Examples:
     my_max([1, 2.1, 3]) => 3
     my_max(['oranges', 'apples', 'pears', 'bananas']) => 'pears'
  """
  ##YOUR CODE GOES HERE
  pass
  
def my_max(L: list[int | float | str]) -> int | float | str:
    # Assume the first element is the maximum
    maximum = L[0]
    for item in L[1:]:
        if item > maximum:
            maximum = item
    return maximum
