def collate(t: tuple[str]) -> tuple[str]:
  """
  Returns a tuple of strings where the answer at each index
  i is formed by using all the ith letters from strings of t

  Examples:
     collate(()) => ()
     collate(("a",)) => ("a",)
     collate(("tee", "ear", "ate")) => ("tea", "eat", "ere")
  """
  ##YOUR CODE GOES HERE
  pass

def collate(t: tuple[str]) -> tuple[str]:
    if not t:
        return ()
    
    length = len(t[0])
    result = []
    
    for i in range(length):
        new_str = ''.join(s[i] for s in t)
        result.append(new_str)
    
    return tuple(result)
