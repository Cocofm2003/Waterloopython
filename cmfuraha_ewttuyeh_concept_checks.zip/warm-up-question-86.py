def sparse(s: str, pos: int) -> None:
  """
  Prints out letters of s from pos to the end one character per line

  Effects: 
     Prints to screen

  Examples:
     sparse("", 0) => None
     and nothing is printed to the screen

     sparse("can", 1) => None
     and the following is printed:
     a
     n
  """
  ##YOUR CODE GOES HERE
  pass

def sparse(s: str, pos: int) -> None:
    for i in range(pos, len(s)):
        print(s[i])
