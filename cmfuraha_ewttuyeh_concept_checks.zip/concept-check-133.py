def last_digit(n):
    return n % 10
    
    