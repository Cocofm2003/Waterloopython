def all_same_type(t: tuple) -> bool:
  """
  Returns True if and only if each element of t has the same type 
  and False otherwise.
  
  Examples:
     all_same_type(()) => True
     all_same_type((2, 5, 3)) => True
     all_same_type((2, 'R', 4.56)) => False
  """
  ##YOUR CODE GOES HERE
  pass

def all_same_type(t: tuple) -> bool:
    if len(t) == 0:
        return True
    first_type = type(t[0])
    for element in t:
        if type(element) != first_type:
            return False
    return True

  