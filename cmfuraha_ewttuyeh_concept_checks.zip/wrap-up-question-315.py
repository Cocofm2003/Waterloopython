def name_change(old, new_last):
  """
  Changes the old string's last name to the string new_last
  
  name_change: Str Str -> Str
  Requires:
     old contains at least one space separating first
     and last name.
  
  Examples:
     name_change("John Doe", "Smith") => "John Smith"
     name_change("Bruce Thomas Wayne", "Willis") => "Bruce Thomas Willis"
  """
  ##YOUR CODE GOES HERE
  pass

def name_change(old: str, new_last: str) -> str:
    # Find the position of the last space in the old name
    last_space_index = old.rfind(" ")
    
    # Replace everything after the last space with new_last
    return old[:last_space_index + 1] + new_last
