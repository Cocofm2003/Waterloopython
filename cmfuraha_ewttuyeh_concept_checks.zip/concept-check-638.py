def non_inc(L: list[int]) -> bool:
  '''
  Returns True if the list L is non-increasing
  and False otherwise
  
  Examples:
     non_inc([]) => True
     non_inc([1]) => True
     non_inc([1, -1]) => True
     non_inc([1, 1]) => True
     non_inc([1, 2, 1]) => False
  '''
  ##YOUR CODE GOES HERE
  pass

def non_inc(L: list[int]) -> bool:
    return all(x >= y for x, y in zip(L, L[1:]))
