class Movie:
  name: str
  year: int
  rating: int

  def __init__(self, n: str, y: int, r: int) -> None:
    """
    Constructor: Create a Movie object by 
    calling Movie(n, y, r)
      
    Effects: Mutates Self
    Requires:
      y > 0
      0 <= r <= 10
    """
    self.name = n
    self.year = y
    self.rating = r
  
  def __repr__(self) -> str:
    """
    Returns a representation of the Movie object
    """
    ##YOUR CODE GOES HERE
    pass
  
class Movie:
    name: str
    year: int
    rating: int

    def __init__(self, n: str, y: int, r: int) -> None:
        self.name = n
        self.year = y
        self.rating = r

    def __repr__(self) -> str:
        return f"{self.name} ({self.year}), {self.rating}"


