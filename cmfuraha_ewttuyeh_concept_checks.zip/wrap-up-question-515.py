def repel(los: list[str], char: str) -> int:
  """
  Mutates los by removing every element 
  of the list of strings los that
  contains char and returns the total
  number of elements mutated.
  
  Effects: Mutates los
  
  Requires: len(char) == 1
  
  Examples:
     L = []
     repel(L, 'a') => 0
     and L is unchanged
     
     L = ['a', 'abc']
     repel(L, 'b') => 1
     and L is mutated to ['a', '']
  """
  ##YOUR CODE GOES HERE
  pass

def repel(los: list[str], char: str) -> int:
    """
    Mutates los by removing every element of the list of strings los that
    contains char and returns the total number of elements mutated.

    Effects: Mutates los
    Requires: len(char) == 1
    """
    count = 0
    for i in range(len(los)):
        if char in los[i]:
            los[i] = ""
            count += 1
    return count
