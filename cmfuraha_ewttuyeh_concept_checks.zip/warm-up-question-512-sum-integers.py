def sum_integers(t: tuple) -> int:
  """
  Returns the sum of all integers in t
  
  Examples:
     sum_integers(()) => 0
     sum_integers(("hi", 5.4, True)) => 0
     sum_integers((2, "apple", 4, 6, 8, (1,), "23")) => 20
  """
  ##YOUR CODE GOES HERE
  pass