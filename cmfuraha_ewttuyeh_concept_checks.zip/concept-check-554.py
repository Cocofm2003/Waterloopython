def add_one(lon: list[int]) -> None:
  """
  Mutates lon by adding 1 to each element
  
  Effects: Mutates lon
  
  Examples:
     L = []
     add_one(L) => None
     and L is unchanged
     
     L = [1, 2, 3]
     add_one(L) => None
     and L is mutated to [2, 3, 4]
  """
  ##YOUR CODE GOES HERE
  pass

def add_one(lon: list[int]) -> None:
    for i in range(len(lon)):
        lon[i] += 1
