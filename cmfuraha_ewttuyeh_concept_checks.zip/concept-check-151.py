def third_side(opp: float, hyp: float) -> float:
  """
  Pythagorean Theorem given the hypotenuse
  in hyp and opposite side in opp

  Requires:
     0.0 < opp < hyp
     
  Examples:
     third_side(4.0, 5.0) => 3.0
  """
  ##YOUR CODE GOES HERE
  pass