def sum_multiples(n: int, k: int) -> int:
  """
  Returns sum of all multiples of k <= n
  
  Requires: 0 < n, k
  
  Examples:
     sum_multiples(1, 1) => 1
     sum_multiples(14, 3) => 30
  """
  ##YOUR CODE GOES HERE

def sum_multiples(n: int, k: int) -> int:
    """
    Returns sum of all multiples of k <= n

    Requires: 0 < n, k

    Examples:
        sum_multiples(1, 1) => 1
        sum_multiples(14, 3) => 30
    """
    total = 0
    for i in range(k, n + 1, k):
        total += i
    return total
