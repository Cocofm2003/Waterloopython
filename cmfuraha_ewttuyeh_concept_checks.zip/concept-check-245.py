def is_leap_year(n: int) -> bool:
  """
  Returns True if n is a leap year and False otherwise.
  
  Requires: 0 < n
  
  Examples:
     is_leap_year(1) => False
     is_leap_year(4) => True
     is_leap_year(100) => False
     is_leap_year(400) => True
  """
  ##YOUR CODE GOES HERE
  pass
  if n % 400 == 0:
      return True
  elif n % 100 == 0:
      return False
  elif n % 4 == 0:
      return True
  else:
      return False