def count_ending(t: tuple[int, ...], digit: int) -> int:
  """
  Returns the number of values in t
  that end with digit
  
  Requires: 0 <= digit <= 9
  
  Examples:
     count_ending((), 3) => 0
     count_ending((13,), 3) => 1
     count_ending((13, 11, 51, 12, 66, 64, 35, 7, 99999999), 1) => 2
  """
  ##YOUR CODE GOES HERE
  pass

def count_ending(t: tuple[int, ...], digit: int) -> int:
    count = 0
    i = 0
    while i < len(t):
        if t[i] % 10 == digit:
            count += 1
        i += 1
    return count
