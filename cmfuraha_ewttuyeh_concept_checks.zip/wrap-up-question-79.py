def add_one(filename: str) -> None:
  """
  Returns None but opens filename and
  increments all values by 1 before saving 
  to a file "shifted.txt"
  
  Effects:
     Reads from file
     Writes to a file
  
  Requires:
  	 filename exists
  
  Examples:
     add_one("empty.txt") => None
     and if "empty.txt" is an empty file,
     "shifted.txt" is also empty.
     
     add_one("onetwothree.txt") => None
     and if "onetwothree.txt" contains:
     1
     2
     3
     "shifted.txt" contains
     2
     3
     4
     
     (Notice the extra newline character after the 4).
  """
  ##YOUR CODE GOES HERE
  pass

def add_one(filename: str) -> None:
    with open(filename, 'r') as infile:
        numbers = [int(line.strip()) + 1 for line in infile if line.strip()]
    with open('shifted.txt', 'w') as outfile:
        for num in numbers:
            outfile.write(f"{num}\n")
