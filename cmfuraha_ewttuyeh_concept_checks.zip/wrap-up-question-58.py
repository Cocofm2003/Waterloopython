def first_digits(L: list[int]) -> None:
  """
  Mutates L so that each element is replaced by the first digit
  
  Effects: Mutates L
  
  Requires: L[i] > 0 for all indices i.
  
  Examples:
     If L is [] then
     first_digits(L) => None
     and L is unchanged
     
     If L is [31, 13] then
     first_digits(L) => None
     and L is mutated to [3, 1]
     
     If L is [1, 2, 3] then
     first_digits(L) => None
     and L is unchanged
  """
  ##YOUR CODE GOES HERE
  pass
  
def first_digits(L: list[int]) -> None:
    """
    Mutates L so that each element is replaced by its first digit.
    """
    for i in range(len(L)):
        while L[i] >= 10:  # Reduce until only one digit remains
            L[i] //= 10
