def intersection(L: list, M: list) -> list:
  """
  Returns a list of common elements in L and M
  
  Requires: L and M do not contain duplicates
  
  Examples:
     intersection([1, 2, 3], []) => []
     intersection([1, 2, 3], [2, 99, 1]) => [1, 2]
  """
  ##YOUR CODE GOES HERE
  pass
  
def intersection(L: list, M: list) -> list:
    """
    Returns a list of common elements in L and M, preserving L's order.
    """
    result = []
    for item in L:
        if item in M:
            result.append(item)
    return result
