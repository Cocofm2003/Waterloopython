def most_ending_digit(L: list[int]) -> int:
  '''
  Returns the single digit that occurs most frequently
  as the last digit of numbers in L. Returns the 
  smallest in the case of a tie.
  
  Requires: 
     len(L) > 0
     L[i] >= 0 for all indices i
  
  Examples:
     most_ending_digit([1,2,3]) => 1
     most_ending_digit([105, 201, 333, 
                        995, 9, 87, 10]) => 5
  '''
  ##YOUR CODE GOES HERE
  pass