def two_ending_cubes(a: int, b: int) -> set[int]:
  '''
  Returns a set of all cubes ending with a 2 between a and b inclusive
  
  Examples:
     two_ending_cubes(0, 0) -> set({})
     two_ending_cubes(-8, 9) -> {8, -8}
  '''
  ##YOUR CODE GOES HERE
  pass

def two_ending_cubes(a: int, b: int) -> set[int]:
    return {x for x in range(a, b + 1) if (x ** 3) % 10 == 2} if a <= b else set()
