def swap(L: list, pos1: int, pos2: int) -> None:
  """
  Swaps L[pos1] and L[pos2]
  
  Effects: Mutates L
  
  0 <= pos1, pos2 < len(L)
  
  Examples:
     L = [1, 2]
     swap(L, 0, 1) => None
     and L is mutated to [2, 1]
  """
  ##YOUR CODE GOES HERE
  pass

def swap(L: list, pos1: int, pos2: int) -> None:
    L[pos1], L[pos2] = L[pos2], L[pos1]
