def make_tuples(n: int) -> list[tuple[int, int, int]]:
  '''
  Returns a list of tuples of the form
  [(0, 1, 2), (1, 2, 3), ..., (n, n+1, n+2)].
  
  Requires: n >= 0
  
  Examples:
     make_tuples(0) => [(0, 1, 2)]
     make_tuples(2) => [(0, 1, 2), (1, 2, 3), (2, 3, 4)]
  '''
  ##YOUR CODE GOES HERE
  pass

def make_tuples(n: int) -> list[tuple[int, int, int]]:
    return [(i, i + 1, i + 2) for i in range(n + 1)]
