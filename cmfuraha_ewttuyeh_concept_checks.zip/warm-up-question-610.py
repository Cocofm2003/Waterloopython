def multi_purpose(L: list[int]) -> int:
  """
  Mutates the list L so it is in reversed order,
  prints out the original list and returns
  the sum of the largest and smallest elements.
  
  Effects: 
     Prints to the screen
     Mutates L
  
  Requires: L is non-empty.
  
  Example:
    L = [1, 2, 3]
    multi_purpose(L) => 4
    L is mutated to [3, 2, 1] and [1, 2, 3] is printed.
  """
  ##YOUR CODE GOES HERE
  pass

def multi_purpose(L: list[int]) -> int:
    # Print the original list
    print(L)
    
    # Find smallest and largest elements
    smallest = L[0]
    largest = L[0]
    
    i = 1
    while i < len(L):
        if L[i] < smallest:
            smallest = L[i]
        if L[i] > largest:
            largest = L[i]
        i += 1
    
    # Reverse the list in place
    left, right = 0, len(L) - 1
    while left < right:
        L[left], L[right] = L[right], L[left]
        left += 1
        right -= 1
    
    # Return sum of smallest and largest
    return smallest + largest
