def inverse_skip_letters(s: str, k: int) -> str:
  """
  Returns a string with every kth letter 
  of s removed
  
  Requires: k > 0
  
  Examples:
     inverse_skip_letters("", 3) => ""
     inverse_skip_letters("a", 3) => ""
     inverse_skip_letters("banana", 2) => "aaa"
  """
  ##YOUR CODE GOES HERE
  pass

def inverse_skip_letters(s: str, k: int) -> str:
    return ''.join(char for i, char in enumerate(s) if i % k != 0)
