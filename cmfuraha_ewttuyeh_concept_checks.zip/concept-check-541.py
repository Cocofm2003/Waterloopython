def product(L: list[int]) -> int:
  """
  Returns the product of all elements in L
  
  Examples:
     product([]) => 1
     product([1,2,3]) => 6
  """
  ##YOUR CODE GOES HERE
  pass

def product(L: list[int]) -> int:
    result = 1
    for num in L:
        result *= num
    return result
