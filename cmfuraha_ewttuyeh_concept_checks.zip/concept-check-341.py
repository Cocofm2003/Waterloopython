def echo():
  n = input("Enter a value:")
  print(n)
    
echo()

import check

def echo():
    n = input("Enter a value:")
    print(n)

# Test case
check.set_input("Hello")          # Simulate user typing "Hello"
check.expect(echo(), None)        # Function should return None
check.expect(check.get_print(), "Hello")  # Printed output should be "Hello"

