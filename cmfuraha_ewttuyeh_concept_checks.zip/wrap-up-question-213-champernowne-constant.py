def champernowne_constant(n: int) -> str:
  """
  Returns Chapernowne's Constant up to and include n
  as a string "0.1234567891011....n"
  
  Requires: n >= 1
  
  Examples:
     champernowne_constant(1) => "0.1"
     champernowne_constant(12) => "0.123456789101112"
  """
  #YOUR CODE GOES HERE
  
def champernowne_constant(n: int) -> str:
    """
    Returns Champernowne's Constant up to and including n as a string "0.1234567891011....n"
    
    Requires: n >= 1
    
    Examples:
        champernowne_constant(1) => "0.1"
        champernowne_constant(12) => "0.123456789101112"
    """
    result = "0."
    for i in range(1, n + 1):
        result += str(i)
    return result
