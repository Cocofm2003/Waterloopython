def foo(L):
  L = L.insert(1, 2)
  print(L)
 
def foo(L):
    L.insert(1, 2)  # Insert 2 at index 1
    print(L)
 