def sum_lasts(lol: list[list[int]]) -> int:
  """
  Returns the sum of all the last values 
  in the nonempty lists in lol
    
  Examples: 
     sum_lasts([]) => 0
     sum_lasts([[]]) => 0
     sum_lasts([[1,2],[],[7,8,9]]) => 11
  """
  ##YOUR CODE GOES HERE
  pass

def sum_lasts(lol: list[list[int]]) -> int:
    total = 0
    for inner_list in lol:
        if inner_list:  # Check if the list is not empty
            total += inner_list[-1]  # Add the last element
    return total
