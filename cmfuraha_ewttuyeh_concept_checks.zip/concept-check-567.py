def rounder(L: list[list[float]]) -> None:
  """
  Mutates the list so the first occurrence of val is negated
  
  Effects: Mutates L
  
  Examples:
     L = []
     rounder(L) => None
     and L is not mutated
     
     L = [[0.3], [3.4,2.3,0.9], [], 
          [16.88,1.3333333,9.0,10.25], [0.51, 1.8887]]
     rounder(L) => None
     and L is mutated to:
     [[0], [3,2,1], [] ,[17,1,9,10], [1, 2]]
  """
  ##YOUR CODE GOES HERE
  pass

def rounder(L: list[list[float]]) -> None:
    for i in range(len(L)):           # Loop through outer list
        for j in range(len(L[i])):    # Loop through each inner list
            L[i][j] = round(L[i][j])  # Round each float and update in place
