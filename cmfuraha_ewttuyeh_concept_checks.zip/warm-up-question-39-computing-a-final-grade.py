def course_grade(warmup: int, inlec: int, wrapup: int,
                         assigs: int , final: int) -> int:
  """
  Returns your course grade
  
  Requires: 
     0 <= warmup, inlec, wrapup, assigs, final <= 100
  
  Examples:
     course_grade(100, 100, 100, 100, 100) => 100
     course_grade(0, 0, 0, 0, 0) => 0
     course_grade(80, 80, 80, 80, 70) => 78
  """
  #YOUR CODE GOES HERE
  pass
  
  grade = (
      0.05 * warmup +
      0.10 * inlec +
      0.05 * wrapup +
      0.60 * assigs +
      0.20 * final
  )
  return round(grade)
