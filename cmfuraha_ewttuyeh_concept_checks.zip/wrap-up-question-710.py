def most_points(filename: str) -> str:
  '''
  Returns player with most points
  give the data in filename
  
  Effects:
     Reads form a file
     
  Requires: 
     Unique player with maximum
     filename exists, is nonempty 
     and is of the correct format
     
  Examples:
     most_points("1985.txt") => 'Wayne Gretzky'
     where "1985.txt" consists of
     Wayne Gretzky,52,163
     Mario Lemieux,45,93
     Paul Coffey,48,90
  '''
  ##YOUR CODE GOES HERE
  pass

def most_points(filename: str) -> str:
    max_points = -1
    best_player = ""
    
    with open(filename) as f:
        for line in f:
            name, goals, assists = line.strip().split(",")
            total_points = int(goals) + int(assists)
            if total_points > max_points:
                max_points = total_points
                best_player = name
                
    return best_player
