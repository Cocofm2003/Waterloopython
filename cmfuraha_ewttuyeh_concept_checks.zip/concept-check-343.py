def n_times() -> None:
  """
  Reads n from keyboard and prints n a total of n times
  once per line
  
  Effects: 
     Reads input from keyboard
     Prints to screen
  
  Examples:
     If 0 is entered after 
     n_times() => None
     is called, then nothing is printed.
  
     If 2 is entered after 
     n_times() => None
     is called, then the following is printed:
     2
     2
     
  """
  ##YOUR CODE GOES HERE
  pass

def n_times() -> None:
    n = int(input())  # Read input from user
    count = 0
    while count < n:
        print(n)
        count += 1
