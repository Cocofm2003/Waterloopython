def almost_equal(S: set[int], T: set[int]) -> bool:
  """
  Returns True if S and T are almost equal and False otherwise
  
  Examples:
     almost_equal(set(), set()) => True
     almost_equal({1}, set()) => False
     almost_equal({2, 4, 6, 8}, {7, 5, 3}) => True
  """
  ##YOUR CODE GOES HERE
  pass

def almost_equal(S: set[int], T: set[int]) -> bool:
    # Check each element in S has a match in T within ±1
    for s in S:
        if not any(abs(s - t) <= 1 for t in T):
            return False
    
    # Check each element in T has a match in S within ±1
    for t in T:
        if not any(abs(t - s) <= 1 for s in S):
            return False
    
    return True
