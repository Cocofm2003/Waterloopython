def sector_area(r: float, theta: float) -> float:
  '''
  Returns the area of a sector of a circle
  given the radius r and angle theta
  
  Requires:
     0.0 <= r
     0.0 <= theta <= 2*math.pi
     
  Example:
     sector_area(0.0, 0.0) => 0.0
     sector_area(1.0, math.pi/2) => 0.785398163397
  '''

def sector_area(r: float, theta: float) -> float:
    """
    Returns the area of a sector of a circle given the radius and angle in radians.
    
    Parameters:
        r (float): Radius of the circle
        theta (float): Angle of the sector in radians
    
    Returns:
        float: Area of the sector
    """
    return 0.5 * r**2 * theta
