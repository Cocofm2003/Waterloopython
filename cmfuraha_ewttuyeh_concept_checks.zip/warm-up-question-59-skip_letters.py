def skip_letters(s: str, k: int) -> str:
  """
  Returns every kth letter of s in a string
  starting from the first character
  
  Requires: k > 0
  
  Examples:
     skip_letters("", 3) => ""
     skip_letters("a", 3) => "a"
     skip_letters("banana", 2) => "bnn"
  """
  ##YOUR CODE GOES HERE
  pass

def skip_letters(s: str, k: int) -> str:
    return s[::k]
