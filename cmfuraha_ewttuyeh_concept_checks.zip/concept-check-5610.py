def max_even_sum(lol: list[list[int]]) -> int:
  """
  Returns the sum of the even integers in the inner list in lol 
  that has the maximal even integer sum
  
  Requires: lol is non-empty
  
  Examples:
     max_even_sum([[]]) => 0
     max_even_sum([[], [3], [10,1,3,5,7], [2,4,6]]) => 12
     max_even_sum([[1,3,5,7],[-10]]) => 0
     max_even_sum([[-2, -4],[-10]]) => -6
  """
  ##YOUR CODE GOES HERE
  pass

def max_even_sum(lol: list[list[int]]) -> int:
    max_sum = None  # Start with None to handle first comparison
    for inner_list in lol:
        current_sum = 0
        for num in inner_list:
            if num % 2 == 0:  # Check if even
                current_sum += num
        if max_sum is None or current_sum > max_sum:
            max_sum = current_sum
    return max_sum
