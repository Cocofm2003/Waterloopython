def contains_positive(t: tuple[int]) -> bool:
  '''
  Returns True if t contains a positive number and False otherwise.
  
  Examples:
     contains_positive(()) => False
     contains_positive((1,)) => True
     contains_positive((-1,)) => False
     contains_positive((-231, -234, -1231234, 5, -1235)) => True
  '''
  ##YOUR CODE GOES HERE
  pass

def contains_positive(t: tuple[int]) -> bool:
    return any(x > 0 for x in t)
