def transpose(t: tuple[tuple[int]]) -> tuple[tuple[int]]:
  '''
  Returns the transpose of t
  
  Requires: len(t[i]) are equal for all 0 <= i < len(t)
  
  Examples:
     transpose(tuple()) => tuple()
     transpose(((1,),)) => ((1,),)
     transpose(((1, 2), (3, 4))) => ((1, 3), (2, 4))
  '''
  ##YOUR CODE GOES HERE
  pass

def transpose(t: tuple[tuple[int]]) -> tuple[tuple[int]]:
    return tuple(map(tuple, zip(*t)))
