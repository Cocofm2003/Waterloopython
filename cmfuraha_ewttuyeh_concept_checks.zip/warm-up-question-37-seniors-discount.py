def seniors(age: int, cost: float) -> float:
  """
  Returns the cost of a meal given the age and cost plus a 2 dollar tip.
  people 55 or over get 15% off.
  
  Requires: 0 <= age
  
  Examples:
     seniors(0, 10.0) => 12.0
     seniors(55, 10.0) => 10.5
  """
  ##YOUR CODE GOES HERE
  pass
  
  if age >= 55:
     cost *= 0.85
  return cost + 2
