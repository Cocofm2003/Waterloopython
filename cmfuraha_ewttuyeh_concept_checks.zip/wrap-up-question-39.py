def sum_triples() -> None:
  """
  Consumes 3 integer inputs from keyboard
  and prints the sum of the three integers
  
  Effects:
     Prints to screen
     Reads input from keyboard
  
  Examples:
     If we call
     sum_triples() => None
     and give integers 1, 2, 3 as input,
     we print "6" to the screen (no quotes)
  """
  ##YOUR CODE GOES HERE
  pass

def sum_triples() -> None:
    # Read three integers from the user
    a = int(input("Enter first integer: "))
    b = int(input("Enter second integer: "))
    c = int(input("Enter third integer: "))
    
    # Compute the sum
    total = a + b + c
    
    # Print the sum
    print(total)
