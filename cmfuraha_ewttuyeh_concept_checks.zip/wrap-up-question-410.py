def even_product(t: tuple[int, ...]) -> int:
  """
  Returns the product of all even numbers in t
  
  Examples:
     even_product(()) => 1
     even_product((11,)) => 1
     even_product((11,2)) => 2
     even_product((2, 3, 4, 5, 6, 7, 8)) => 384
  """
  ##YOUR CODE GOES HERE
  pass

def even_product(t: tuple[int, ...]) -> int:
    """
    Returns the product of all even numbers in t.
    If no even numbers are present, returns 1.
    """
    product = 1
    for num in t:
        if num % 2 == 0:
            product *= num
    return product
