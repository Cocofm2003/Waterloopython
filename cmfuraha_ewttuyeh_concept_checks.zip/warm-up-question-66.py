def sum_last_digits(L: list[int]) -> int:
  """
  Returns the sum of all last digits of L
  
  Examples:
     sum_last_digits([]) => 0
     sum_last_digits([1, 2, 3]) => 6
     sum_last_digits([15, 23, 44]) => 12
  """
  ##YOUR CODE GOES HERE
  pass

def sum_last_digits(L: list[int]) -> int:
    return sum(x % 10 for x in L)
