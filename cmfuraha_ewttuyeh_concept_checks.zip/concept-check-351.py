def userid(first_name: str, middle_name: str, last_name: str) -> str:
  """
  Returns the at most 8 character user id 
  given the first middle and last name
  
  Requires:
     1 <= len(first_name)
     1 <= len(last_name)
     
  Examples:
     userid("Harry", "James", "Potter") => "hjpotter"
     userid("Ronald", "Bilius", "Weasley") => "rbweasle"
     
  """
  ##YOUR CODE GOES HERE
  pass

def userid(first_name, middle_name, last_name):
    # Get first letter of first name
    user_id = first_name[0]
    
    # Add first letter of middle name if it exists
    if middle_name:
        user_id += middle_name[0]
    
    # Add last name (truncated if necessary)
    user_id += last_name[:8 - len(user_id)]
    return user_id.lower()
