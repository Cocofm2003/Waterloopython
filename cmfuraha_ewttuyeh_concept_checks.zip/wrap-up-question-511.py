def halve_evens_ret(L: list[int]) -> list[int]:
  """
  Returns a copy of L with all even numbers divided by 2
  
  Examples:
     halve_evens_ret([]) => []
     halve_evens_ret([1,3,5,7]) => [1,3,5,7]
     halve_evens_ret([1,2,3,4]) => [1,1,3,2]
  """
  ##YOUR CODE GOES HERE
  pass

def halve_evens_ret(L: list[int]) -> list[int]:
    """
    Returns a copy of L with all even numbers divided by 2.
    """
    result = []
    for x in L:
        if x % 2 == 0:
            result.append(x // 2)
        else:
            result.append(x)
    return result
