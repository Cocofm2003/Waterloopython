
def num_a(s: str) -> int:
    """
    Returns the number of 'a' characters in s
    """
    if s == "":  # Base case: empty string
        return 0
    ct = 1 if s[0] == 'a' else 0  # Count if first char is 'a'
    return ct + num_a(s[1:])  # Recurse on the rest of the string

