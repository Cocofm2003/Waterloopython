def convert_to_letter_grade(lon: list[int]) -> list[str]:
  '''
  Returns a new list where each value in lon
  is replaced by a letter grade
  
  Requires: 0 <= L[i] <= 100 for each 0 <= i <= len(L)
  
  Examples:
     convert_to_letter_grade([]) => []
     convert_to_letter_grade([0]) => ['F']
     convert_to_letter_grade([49, 59, 69, 79, 89]) 
        => ['F', 'D', 'C', 'B', 'A']
  '''
  ##YOUR CODE GOES HERE
  pass

def convert_to_letter_grade(lon: list[int]) -> list[str]:
    def to_grade(n: int) -> str:
        if n >= 80:
            return 'A'
        elif n >= 70:
            return 'B'
        elif n >= 60:
            return 'C'
        elif n >= 50:
            return 'D'
        else:
            return 'F'
    
    return list(map(to_grade, lon))
