def negate_first(L: list[list[int]], val: int):
  '''
  Mutates the list so the first occurrence of val is negated
  
  Effects: Mutates L
  
  Requires: 
     val occurs in L and is positive
  
  Examples:
     L = []
     negate_first(L, 10) => None
     and L is not mutated
     
     L = [[0], [3,2,1], [] ,[17,1,9,10], [1, 2]]
     negate_first(L, 1) => None
     and L is mutated to:
     [[0], [3,2,-1], [] ,[17,1,9,10], [1, 2]]
  '''
  ##YOUR CODE GOES HERE
  pass

def negate_first(L: list[list[int]], val: int) -> None:
    """
    Mutates the list so the first occurrence of val is negated.

    Effects: Mutates L
    Requires: val occurs in L and is positive
    """
    for sublist in L:
        for i in range(len(sublist)):
            if sublist[i] == val:
                sublist[i] = -val
                return None
    return None
