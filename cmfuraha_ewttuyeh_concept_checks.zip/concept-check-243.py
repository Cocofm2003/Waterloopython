def my_cat(x):
  #YOUR CODE GOES HERE
  if x <= 5:
   return "very small"
  elif x < 10:
   return "small"
  else:
   return "big"
        