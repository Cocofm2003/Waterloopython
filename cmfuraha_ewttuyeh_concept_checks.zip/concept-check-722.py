def longest_name(filename: str) -> str:
  '''
  Consumes a string filename that is a file
  present in the current directory with names first last
  in white space separated format (one name per line)
  and returns the person with the longest name 
  (or the first person in the case of a tie)
  
  Effects: 
     Reads from file in filename
  
  Requires: filename is a valid filename in the directory.
  
  Example:
     longest_name("names-small.txt") => 'John Smith'
     Assuming names-small.txt contains
     John Smith
     Jane Doe
     Mike Lower
     
  '''
  ##YOUR CODE GOES HERE
  pass

def longest_name(filename: str) -> str:
    with open(filename, 'r') as file:
        names = [line.strip() for line in file]
    return max(names, key=len)
