def sigma(n: int) -> int:
  """
  Returns sum of all positive integer divisors of n
  
  Requires: 0 < n
  
  Examples:
     sigma(1) => 1
     sigma(6) => 12
  """
  ##YOUR CODE GOES HERE
  pass

def sigma(n: int) -> int:
    # Ensure n is positive
    if n <= 0:
        raise ValueError("n must be a positive integer")
    
    # Sum of all divisors
    total = 0
    for d in range(1, n + 1):
        if n % d == 0:
            total += d
    return total
