def tuple_sort(L: list[tuple[int, int, int]]) \
                -> list[tuple[int, int, int]]:
  """
  Returns a new list of triples sorted by largest median value
  with ties broken by largest product.
  
  Examples:
     tuple_sort([]) => []
     tuple_sort([(1,2,3)]) => [(1,2,3)]
     tuple_sort([(1,2,3), (6,2,5)]) => [(6,2,5), (1,2,3)]
  """
  pass

def tuple_sort(L: list[tuple[int, int, int]]) -> list[tuple[int, int, int]]:
    def median(t):
        return sorted(t)[1]  # middle value of sorted tuple
    
    def product(t):
        return t[0] * t[1] * t[2]
    
    return sorted(L, key=lambda t: (median(t), product(t)), reverse=True)
