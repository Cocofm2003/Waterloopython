
def count_a(s: str) -> int:
    """
    Returns the number of 'a' characters in s.
    Examples:
    count_a('') => 0
    count_a('abca') => 2
    """
    pos = 0
    ans = 0
    while pos < len(s):
        if s[pos] == 'a':
            ans += 1
        pos += 1
    return ans
