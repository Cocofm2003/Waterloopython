def equinumerous(s: str) -> bool:
  '''
  Returns True if s is equinumerous and False otherwise.
  
  Examples:
     equinumerous("0") => False
     equinumerous("1010") => True
  '''
  ##YOUR CODE GOES HERE
  pass

def equinumerous(s: str) -> bool:
    counts = {'0': 0, '1': 0}
    for ch in s:
        counts[ch] += 1
    return counts['0'] == counts['1']
