def euler(n: int) -> int:
  """
  Returns phi(n)
  
  Requires: 0 < n
  
  Examples:
     euler(1) => 1
     euler(6) => 2
     euler(7) => 6
     euler(10) => 4
  """
  ##YOUR CODE GOES HERE
  pass

import math

def euler(n: int) -> int:
    # Ensure n is positive
    if n <= 0:
        raise ValueError("n must be a positive integer")
    
    # Count numbers that are coprime with n
    count = 0
    for d in range(1, n + 1):
        if math.gcd(d, n) == 1:
            count += 1
    return count
