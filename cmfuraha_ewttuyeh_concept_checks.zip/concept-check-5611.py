def column(grid: list[list[int]] , col_num: int) -> list[int]:
  '''
  Returns the col_num column of grid
  
  Requires: 
     grid is not empty
     len(grid) == len(grid[i]) for all indices i
     0 <= col_num <= len(grid)-1
  
  Examples:
     column([[1]], 0) => [1]
     column([[43,35],[336,42]], 1) => [35, 42]
  '''
  ##YOUR CODE GOES HERE
  pass

def column(grid: list[list[int]], col_num: int) -> list[int]:
    result = []
    for row in grid:
        result.append(row[col_num])
    return result
